package com.capgemini.contactbook.exception;

public class ContactBookException extends Exception
{
	public ContactBookException(String messege)
	{
		super(messege);
	}
}
